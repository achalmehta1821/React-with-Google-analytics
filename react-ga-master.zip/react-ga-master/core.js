// eslint-disable-next-line import/no-unresolved
const index = require('./dist/react-ga-core');

module.exports = index.default;
