module.exports = {
  '*.{js,jsx}': 'eslint --ext .js,.jsx'
};
