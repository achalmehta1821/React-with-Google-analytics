export default function loadGA() {}
