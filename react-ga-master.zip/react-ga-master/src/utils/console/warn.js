export default function warn(s) {
  console.warn('[react-ga]', s);
}
