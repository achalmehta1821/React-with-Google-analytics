export default function log(s) {
  console.info('[react-ga]', s);
}
